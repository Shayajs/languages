from module.util import Donnees, center, setBackgroundColor, getBackgroundColor, choicedBackgroundColor
from pathlib import Path
from PyQt5.QtCore import QMargins
from PyQt5.QtWidgets import QApplication, QLineEdit, QWidget, QPushButton, QLabel, QVBoxLayout, QRadioButton
from PyQt5.QtGui import QIcon, QFont

class PythonTogether:
    
    def __init__(self) -> None:
        pass