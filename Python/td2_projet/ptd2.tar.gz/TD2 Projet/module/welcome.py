from PyQt5.QtCore import QMargins
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout, QRadioButton
from PyQt5.QtGui import QIcon, QFont
import sys
import os

if __name__ == "__main__":
    sys.path.append(os.path.dirname(os.path.realpath("main.py")))

from module.util import Donnees, center, setBackgroundColor, getBackgroundColor, choicedBackgroundColor

class WelcomeWindow:
    """
    C'est la page principale après connexion
    """

    def __init__(self):

        self.colorText = "color: black;"

        if choicedBackgroundColor() == 1:
            self.colorText = "color: white;"

        self.user = Donnees.current_user['user']
        self.version = Donnees.version
        self.isAdmin = Donnees.current_user['admin']

        self.app = QApplication(sys.argv)
        self.win = QWidget()
        x, y = 1280, 720
        self.x, self.y = center(x, y)
        self.win.setGeometry(self.x, self.y, x, y)

        if not self.isAdmin:
            self.win.setWindowTitle(f"Projets SPI — {self.user} — {self.version}")
        elif self.isAdmin:
            self.win.setWindowTitle(f"Projets SPI — {self.user} — {self.version} (Administrateur)")

        self.win.setWindowIcon(QIcon("./bin/icon1"))
        self.win.show()

        self.label0 = QLabel(self.win)
        self.label0.move(0, 0)
        self.label0.resize(x, y)
        self.label0.setStyleSheet(getBackgroundColor())
        self.label0.show()
        self.v_box = QVBoxLayout()
        self.v_box.addWidget(self.label0)
        self.v_box.setSpacing(0)
        self.v_box.setContentsMargins(QMargins(0,0,0,0))
        self.win.setLayout(self.v_box)

        self.label1 = QLabel(self.win)
        if self.user != "Hors Ligne":
            self.label1.setText(f"Bonjour {self.user}")
        else:
            self.label1.setText(f"Vous êtes {self.user}")
        self.label1.setStyleSheet(self.colorText)
        self.label1.move(20, 20)
        self.label1.setFont(QFont('Mangal', 50))
        self.label1.adjustSize()
        self.label1.show()

        self.label2 = QLabel(self.win)
        if self.user != "Hors Ligne":
            self.label2.setText(f"Désolé {self.user}, cette version ne permet pas de faire plus qu'afficher ces deux textes.\nAttendez une version future pour cela.")
        else:
            self.label2.setText("Désolé, cette version ne permet pas de faire plus qu'afficher ces deux textes.\nAttendez une version future pour cela. Et en ligne.")
        self.label2.move(20, 140)
        self.label2.setFont(QFont('Mangal', 15))
        self.label2.setStyleSheet(self.colorText)
        self.label2.adjustSize()
        self.label2.show()

        self.label3 = QLabel(self.win)
        self.label3.setText(f"Mais la version {self.version} permet actuellement de paramétrer le thème et de se connecter en ligne.\nPlus qu'à un pas pour Python Together !")
        self.label3.move(20, 300)
        self.label3.setFont(QFont('Mangal', 15))
        self.label3.setStyleSheet(self.colorText)
        self.label3.adjustSize()
        self.label3.show()

        self.bouton1 = QPushButton(self.win)
        self.bouton1.setText("Paramètres")
        self.bouton1.move(980, 100)
        self.bouton1.clicked.connect(self.parameters)
        self.bouton1.show()

        self.label3 = QLabel(self.win)
        self.label3.setText(f"Projets en cours :\n  * Python Together Poitiers\n    * Voiture télécommandée")
        self.label3.move(20, 210)
        self.label3.setFont(QFont('Mangal', 15))
        self.label3.setStyleSheet(self.colorText)
        self.label3.adjustSize()
        self.label3.show()

        sys.exit(self.app.exec_())
        
    def parameters(self):
        """
        Module des paramètres
        """
        self.win2 = QWidget()
        x, y = 450, 720
        self.x, self.y = center(x, y)
        self.win2.setGeometry(self.x, self.y, x, y)

        if not self.isAdmin:
            self.win2.setWindowTitle(f"Paramètres — {self.user}")
        elif self.isAdmin:
            self.win2.setWindowTitle(f"Paramètres — {self.user} (Administrateur)")

        self.win2.setWindowIcon(QIcon("./bin/icon1"))
        self.win2.show()

        self.label02 = QLabel(self.win2)
        self.label02.move(0, 0)
        self.label02.resize(x, y)
        self.label02.setStyleSheet(getBackgroundColor())
        self.label02.show()

        self.label22 = QLabel(self.win2)
        self.label22.setText("Thème")
        self.label22.move(20, 20)
        self.label22.setFont(QFont('Mangal', 15))
        self.label22.setStyleSheet(self.colorText)
        self.label22.adjustSize()
        self.label22.show()

        self.radio1 = QRadioButton(self.win2)
        self.radio1.setText("Mode Sombre")
        self.radio1.toggled.connect(lambda: setBackgroundColor(1))
        self.radio1.setStyleSheet(self.colorText)
        self.radio1.move(20, 60)

        if choicedBackgroundColor() == 1:
            self.radio1.setChecked(True)

        self.radio1.show()

        self.radio2 = QRadioButton(self.win2)
        self.radio2.setText("Mode Clair")
        self.radio2.toggled.connect(lambda: setBackgroundColor(2))
        self.radio2.setStyleSheet(self.colorText)
        self.radio2.move(20, 80)

        if choicedBackgroundColor() == 2:
            self.radio2.setChecked(True)

        self.radio2.show()
    
    def __del__(self):
        print("Bye bye")
        

if __name__ == "__main__":
    Donnees.current_user = {'user': "Test", "admin": True}
    from connexion import version
    Donnees.version = version
    test = WelcomeWindow()
    exit()
